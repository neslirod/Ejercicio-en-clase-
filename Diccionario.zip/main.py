
informacion_contacto = {
    'nombre': 'Ana',
    'apellido': 'García',
    'edad': 28,
    'ciudad': 'Barcelona'
}


nombre_contacto = informacion_contacto['nombre']


informacion_contacto['edad'] = 29

print(informacion_contacto)   

