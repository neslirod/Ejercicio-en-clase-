
frutas = ['manzana', 'plátano', 'cereza', 'mango']


frutas.append('naranja')


primera_fruta = frutas[0]


frutas[2] = 'pera'

print(frutas)  
