

vocales= [ "a", "e", "i", "o", "u"]
nombres= input ("ingrese el nombre: ")	
numero_vocales= 0

for item in list(nombres):
  if item in vocales: 
    numero_vocales+= 1

if numero_vocales >=3:
  print(nombres)
else:
  print("no cumple con la condicion")
  


  
    