
paises = ('España', 'Francia', 'Italia')


primer_pais = paises[0]

print(paises)  
